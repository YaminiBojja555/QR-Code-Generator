import { useEffect, useState } from "react";
import { useParams } from "wouter";
import { Layout } from "@/components/layout";
import { UserAvatar } from "@/components/ui/user-avatar";
import { Button } from "@/components/ui/button";
import { PostCard } from "@/components/post-card";
import { useQuery, useMutation } from "@tanstack/react-query";
import { PostWithUser, User, UserWithStats } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Edit, User as UserIcon, Users } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";

const profileSchema = z.object({
  displayName: z.string().min(1, "Display name is required"),
  bio: z.string().optional(),
  avatarUrl: z.string().url("Must be a valid URL").or(z.string().length(0)).optional(),
});

export default function ProfilePage() {
  const { id } = useParams<{ id: string }>();
  const userId = parseInt(id);
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  
  const isCurrentUserProfile = currentUser?.id === userId;
  
  const {
    data: profile,
    isLoading: isProfileLoading,
    error: profileError,
  } = useQuery<UserWithStats>({
    queryKey: [`/api/users/${userId}`],
  });
  
  const {
    data: posts,
    isLoading: isPostsLoading,
    error: postsError,
  } = useQuery<PostWithUser[]>({
    queryKey: [`/api/users/${userId}/posts`],
  });
  
  const form = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      displayName: profile?.displayName || "",
      bio: profile?.bio || "",
      avatarUrl: profile?.avatarUrl || "",
    },
  });
  
  // Update form values when profile data is loaded
  useEffect(() => {
    if (profile) {
      form.reset({
        displayName: profile.displayName,
        bio: profile.bio || "",
        avatarUrl: profile.avatarUrl || "",
      });
    }
  }, [profile, form]);
  
  const updateProfileMutation = useMutation({
    mutationFn: async (values: z.infer<typeof profileSchema>) => {
      const res = await apiRequest("PATCH", `/api/users/${userId}`, values);
      return await res.json();
    },
    onSuccess: (updatedUser: User) => {
      queryClient.setQueryData([`/api/users/${userId}`], {
        ...profile,
        ...updatedUser,
      });
      
      setIsEditDialogOpen(false);
      
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    },
  });
  
  const followMutation = useMutation({
    mutationFn: async () => {
      if (profile?.isFollowing) {
        await apiRequest("DELETE", `/api/users/${userId}/follow`);
      } else {
        await apiRequest("POST", `/api/users/${userId}/follow`);
      }
    },
    onMutate: () => {
      // Optimistic update
      const previousProfile = { ...profile };
      
      queryClient.setQueryData([`/api/users/${userId}`], {
        ...profile,
        isFollowing: !profile?.isFollowing,
        followersCount: profile?.isFollowing 
          ? (profile.followersCount - 1) 
          : (profile?.followersCount || 0) + 1
      });
      
      return { previousProfile };
    },
    onError: (_error, _variables, context) => {
      // Revert on error
      queryClient.setQueryData([`/api/users/${userId}`], context?.previousProfile);
      
      toast({
        title: "Error",
        description: "There was an error updating follow status",
        variant: "destructive",
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
    },
  });
  
  const onSubmit = (values: z.infer<typeof profileSchema>) => {
    updateProfileMutation.mutate(values);
  };
  
  if (isProfileLoading) {
    return (
      <Layout>
        <div className="flex justify-center py-20">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }
  
  if (profileError || !profile) {
    return (
      <Layout>
        <div className="text-center py-20">
          <p className="text-destructive text-lg">Failed to load profile</p>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="bg-white rounded-lg shadow mb-6 overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-blue-400 to-blue-600"></div>
        <div className="p-6 relative">
          <div className="flex flex-col sm:flex-row items-center sm:items-start">
            <div className="absolute -top-12 sm:-top-16 left-1/2 sm:left-6 transform -translate-x-1/2 sm:translate-x-0">
              <UserAvatar user={profile} size="xl" />
            </div>
            
            <div className="mt-12 sm:mt-0 sm:ml-28 text-center sm:text-left flex-1">
              <h1 className="text-2xl font-bold">{profile.displayName}</h1>
              <p className="text-gray-500">@{profile.username}</p>
              
              {profile.bio && (
                <p className="mt-2 text-gray-700">{profile.bio}</p>
              )}
              
              <div className="flex items-center justify-center sm:justify-start space-x-4 mt-3">
                <div className="flex items-center">
                  <Users className="h-4 w-4 mr-1 text-gray-500" />
                  <span className="text-sm">
                    <span className="font-bold">{profile.followersCount}</span> followers
                  </span>
                </div>
                <div className="flex items-center">
                  <UserIcon className="h-4 w-4 mr-1 text-gray-500" />
                  <span className="text-sm">
                    <span className="font-bold">{profile.followingCount}</span> following
                  </span>
                </div>
              </div>
            </div>
            
            <div className="mt-4 sm:mt-0">
              {isCurrentUserProfile ? (
                <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4 mr-2" /> Edit Profile
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Profile</DialogTitle>
                      <DialogDescription>
                        Make changes to your profile information.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                          control={form.control}
                          name="displayName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Display Name</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="bio"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Bio</FormLabel>
                              <FormControl>
                                <Textarea 
                                  {...field} 
                                  placeholder="Tell others about yourself" 
                                  className="resize-none"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="avatarUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Avatar URL</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="https://example.com/avatar.jpg" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <DialogFooter>
                          <Button type="submit" disabled={updateProfileMutation.isPending}>
                            {updateProfileMutation.isPending ? "Saving..." : "Save changes"}
                          </Button>
                        </DialogFooter>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              ) : (
                <Button
                  variant={profile.isFollowing ? "outline" : "default"}
                  onClick={() => followMutation.mutate()}
                  disabled={followMutation.isPending}
                >
                  {profile.isFollowing ? "Unfollow" : "Follow"}
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <Tabs defaultValue="posts" className="mb-6">
        <TabsList>
          <TabsTrigger value="posts">Posts</TabsTrigger>
          {/* Could add more tabs in the future like "Media", "Likes", etc. */}
        </TabsList>
        
        <TabsContent value="posts" className="mt-6">
          {isPostsLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : postsError ? (
            <div className="text-center py-12">
              <p className="text-destructive">Failed to load posts</p>
            </div>
          ) : posts && posts.length > 0 ? (
            <div>
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg shadow">
              <h3 className="text-lg font-medium">No posts yet</h3>
              <p className="text-muted-foreground">
                {isCurrentUserProfile 
                  ? "Share your first post with the community!" 
                  : `${profile.displayName} hasn't posted anything yet.`}
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </Layout>
  );
}
