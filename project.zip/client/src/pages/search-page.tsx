import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { UserAvatar } from "@/components/ui/user-avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search as SearchIcon, Loader2 } from "lucide-react";
import { User } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";

export default function SearchPage() {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  
  // Extract query parameter from URL
  useEffect(() => {
    const params = new URLSearchParams(location.split("?")[1]);
    const q = params.get("q");
    if (q) {
      setSearchQuery(q);
    }
  }, [location]);
  
  const {
    data: searchResults,
    isLoading,
    error,
    refetch,
  } = useQuery<User[]>({
    queryKey: ["/api/users/search", searchQuery],
    queryFn: async ({ queryKey }) => {
      const [_, query] = queryKey;
      if (!query) return [];
      
      const res = await fetch(`/api/users/search?q=${encodeURIComponent(query)}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to search users");
      return res.json();
    },
    enabled: searchQuery.length > 0,
  });
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      refetch();
    }
  };
  
  return (
    <Layout>
      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <h1 className="text-2xl font-bold mb-4">Search People</h1>
        
        <form onSubmit={handleSearch} className="mb-4">
          <div className="relative">
            <SearchIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
            <Input
              type="text"
              placeholder="Search by username or display name"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <Button 
              type="submit" 
              className="absolute right-1 top-1/2 -translate-y-1/2 h-8"
              disabled={!searchQuery.trim() || isLoading}
            >
              Search
            </Button>
          </div>
        </form>
        
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="text-center py-8">
            <p className="text-destructive">An error occurred while searching</p>
          </div>
        ) : searchResults && searchResults.length > 0 ? (
          <div className="divide-y">
            {searchResults.map((user) => (
              <div key={user.id} className="py-4 flex items-center justify-between">
                <Link href={`/profile/${user.id}`} className="flex items-center space-x-3 hover:opacity-80">
                  <UserAvatar user={user} />
                  <div>
                    <p className="font-medium">{user.displayName}</p>
                    <p className="text-sm text-gray-500">@{user.username}</p>
                  </div>
                </Link>
                <Link href={`/profile/${user.id}`}>
                  <Button variant="outline" size="sm">View Profile</Button>
                </Link>
              </div>
            ))}
          </div>
        ) : searchQuery && !isLoading ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No users found matching "{searchQuery}"</p>
          </div>
        ) : null}
        
        {!searchQuery && (
          <div className="text-center py-8 text-gray-500">
            <p>Enter a username or display name to search for users</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
