import { Layout } from "@/components/layout";
import { CreatePost } from "@/components/create-post";
import { PostCard } from "@/components/post-card";
import { useQuery } from "@tanstack/react-query";
import { PostWithUser } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";

export default function HomePage() {
  const {
    data: feedPosts,
    isLoading: isFeedLoading,
    error: feedError,
  } = useQuery<PostWithUser[]>({
    queryKey: ["/api/feed"],
  });
  
  const {
    data: discoverPosts,
    isLoading: isDiscoverLoading,
    error: discoverError,
  } = useQuery<PostWithUser[]>({
    queryKey: ["/api/posts"],
  });
  
  return (
    <Layout>
      <CreatePost />
      
      <Tabs defaultValue="feed" className="mb-8">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="feed">My Feed</TabsTrigger>
          <TabsTrigger value="discover">Discover</TabsTrigger>
        </TabsList>
        
        <TabsContent value="feed">
          {isFeedLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : feedError ? (
            <div className="text-center py-12">
              <p className="text-destructive">Failed to load feed</p>
            </div>
          ) : feedPosts && feedPosts.length > 0 ? (
            <div>
              {feedPosts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg shadow border border-gray-100">
              <h3 className="text-lg font-medium mb-2">Your feed is empty</h3>
              <p className="text-muted-foreground mb-4">
                Start following people to see their posts in your feed.
              </p>
              <p className="text-sm text-muted-foreground">
                Check out the Discover tab to find interesting people to follow.
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="discover">
          {isDiscoverLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : discoverError ? (
            <div className="text-center py-12">
              <p className="text-destructive">Failed to load discover feed</p>
            </div>
          ) : discoverPosts && discoverPosts.length > 0 ? (
            <div>
              {discoverPosts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg shadow border border-gray-100">
              <h3 className="text-lg font-medium">No posts yet</h3>
              <p className="text-muted-foreground">
                Be the first to share something with the community!
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </Layout>
  );
}
