import { CommentWithUser } from "@shared/schema";
import { UserAvatar } from "@/components/ui/user-avatar";
import { formatDistanceToNow } from "date-fns";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface CommentItemProps {
  comment: CommentWithUser;
}

export function CommentItem({ comment }: CommentItemProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const deleteCommentMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/comments/${comment.id}`);
    },
    onSuccess: () => {
      // Remove the comment from the UI
      queryClient.setQueryData([`/api/posts/${comment.postId}/comments`], (old: CommentWithUser[] | undefined) => {
        if (!old) return old;
        return old.filter(c => c.id !== comment.id);
      });
      
      // Update the comment count
      queryClient.setQueryData(["/api/feed"], (old: any[] | undefined) => {
        if (!old) return old;
        return old.map(post => {
          if (post.id === comment.postId) {
            return {
              ...post,
              commentCount: post.commentCount - 1
            };
          }
          return post;
        });
      });
      
      queryClient.setQueryData(["/api/posts"], (old: any[] | undefined) => {
        if (!old) return old;
        return old.map(post => {
          if (post.id === comment.postId) {
            return {
              ...post,
              commentCount: post.commentCount - 1
            };
          }
          return post;
        });
      });
      
      toast({
        title: "Success",
        description: "Comment deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete comment",
        variant: "destructive",
      });
    },
  });
  
  return (
    <div className="flex space-x-2">
      <Link href={`/profile/${comment.user.id}`}>
        <UserAvatar user={comment.user} size="sm" />
      </Link>
      <div className="flex-1 bg-muted p-3 rounded-lg">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center space-x-2">
            <Link href={`/profile/${comment.user.id}`} className="font-medium hover:underline">
              {comment.user.displayName}
            </Link>
            <span className="text-xs text-muted-foreground">
              {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
            </span>
          </div>
          
          {user?.id === comment.user.id && (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
              onClick={() => deleteCommentMutation.mutate()}
              disabled={deleteCommentMutation.isPending}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
        <p className="text-sm">{comment.content}</p>
      </div>
    </div>
  );
}
