import { useState } from "react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { UserAvatar } from "@/components/ui/user-avatar";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ImageIcon, XCircle } from "lucide-react";

export function CreatePost() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [content, setContent] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [showImageInput, setShowImageInput] = useState(false);
  
  const createPostMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/posts", {
        content,
        imageUrl: imageUrl || undefined
      });
      return res.json();
    },
    onSuccess: () => {
      setContent("");
      setImageUrl("");
      setShowImageInput(false);
      
      queryClient.invalidateQueries({ queryKey: ["/api/feed"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      
      toast({
        title: "Success",
        description: "Post created successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create post",
        variant: "destructive",
      });
    },
  });
  
  if (!user) return null;
  
  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <div className="flex space-x-3">
          <UserAvatar user={user} />
          <div className="flex-1">
            <Textarea
              placeholder="What's on your mind?"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="resize-none border-0 focus-visible:ring-0 p-0 min-h-24"
              style={{ boxShadow: 'none' }}
            />
            
            {showImageInput && (
              <div className="mt-2 relative">
                <input
                  type="text"
                  placeholder="Enter image URL"
                  className="w-full p-2 pr-8 border rounded-md text-sm"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                />
                <button 
                  className="absolute right-2 top-1/2 transform -translate-y-1/2"
                  onClick={() => {
                    setImageUrl("");
                    setShowImageInput(false);
                  }}
                >
                  <XCircle className="h-5 w-5 text-muted-foreground hover:text-destructive" />
                </button>
              </div>
            )}
            
            {imageUrl && (
              <div className="mt-3 rounded-md overflow-hidden">
                <img 
                  src={imageUrl} 
                  alt="Preview" 
                  className="w-full h-auto max-h-72 object-cover"
                  onError={() => {
                    toast({
                      title: "Error",
                      description: "Failed to load image",
                      variant: "destructive",
                    });
                    setImageUrl("");
                  }}
                />
              </div>
            )}
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="border-t p-3 flex justify-between">
        <Button
          variant="ghost"
          size="sm"
          className="text-muted-foreground"
          onClick={() => setShowImageInput(!showImageInput)}
        >
          <ImageIcon className="h-5 w-5 mr-1" />
          Add Image
        </Button>
        
        <Button
          size="sm"
          onClick={() => createPostMutation.mutate()}
          disabled={!content.trim() || createPostMutation.isPending}
        >
          Post
        </Button>
      </CardFooter>
    </Card>
  );
}
