import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User } from "@shared/schema";

interface UserAvatarProps {
  user: Partial<User>;
  size?: "sm" | "md" | "lg" | "xl";
}

export function UserAvatar({ user, size = "md" }: UserAvatarProps) {
  const sizeClasses = {
    sm: "h-8 w-8",
    md: "h-10 w-10",
    lg: "h-16 w-16",
    xl: "h-24 w-24",
  };

  const fallbackText = user.displayName 
    ? `${user.displayName.charAt(0)}` 
    : user.username 
      ? `${user.username.charAt(0)}` 
      : "?";

  return (
    <Avatar className={sizeClasses[size]}>
      <AvatarImage src={user.avatarUrl} alt={user.username || "User"} />
      <AvatarFallback className="bg-primary/10 text-primary">
        {fallbackText.toUpperCase()}
      </AvatarFallback>
    </Avatar>
  );
}
