import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { UserAvatar } from "@/components/ui/user-avatar";
import { PostWithUser, CommentWithUser } from "@shared/schema";
import { Heart, MessageCircle, Trash2, MoreHorizontal } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { CommentItem } from "./comment-item";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface PostCardProps {
  post: PostWithUser;
  showComments?: boolean;
}

export function PostCard({ post, showComments = false }: PostCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [commentContent, setCommentContent] = useState("");
  const [showCommentsSection, setShowCommentsSection] = useState(showComments);
  const [comments, setComments] = useState<CommentWithUser[]>([]);
  const [isLoadingComments, setIsLoadingComments] = useState(false);

  const toggleLikeMutation = useMutation({
    mutationFn: async () => {
      if (post.isLiked) {
        await apiRequest("DELETE", `/api/posts/${post.id}/likes`);
      } else {
        await apiRequest("POST", `/api/posts/${post.id}/likes`);
      }
    },
    onMutate: () => {
      // Optimistic update
      const previousPost = { ...post };
      
      queryClient.setQueryData(["/api/feed"], (old: PostWithUser[] | undefined) => {
        if (!old) return old;
        return old.map(p => {
          if (p.id === post.id) {
            return {
              ...p,
              isLiked: !p.isLiked,
              likeCount: p.isLiked ? p.likeCount - 1 : p.likeCount + 1
            };
          }
          return p;
        });
      });
      
      queryClient.setQueryData(["/api/posts"], (old: PostWithUser[] | undefined) => {
        if (!old) return old;
        return old.map(p => {
          if (p.id === post.id) {
            return {
              ...p,
              isLiked: !p.isLiked,
              likeCount: p.isLiked ? p.likeCount - 1 : p.likeCount + 1
            };
          }
          return p;
        });
      });
      
      return { previousPost };
    },
    onError: (_error, _variables, context) => {
      // Revert on error
      queryClient.setQueryData(["/api/feed"], (old: PostWithUser[] | undefined) => {
        if (!old) return old;
        return old.map(p => p.id === post.id ? context?.previousPost : p);
      });
      
      queryClient.setQueryData(["/api/posts"], (old: PostWithUser[] | undefined) => {
        if (!old) return old;
        return old.map(p => p.id === post.id ? context?.previousPost : p);
      });
      
      toast({
        title: "Error",
        description: "There was an error updating like status",
        variant: "destructive",
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/feed"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
  });

  const deletePostMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/posts/${post.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/feed"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      
      toast({
        title: "Success",
        description: "Post deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete post",
        variant: "destructive",
      });
    },
  });

  const addCommentMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/comments`, {
        content: commentContent,
      });
      return res.json();
    },
    onSuccess: (newComment) => {
      setCommentContent("");
      setComments(prev => [newComment, ...prev]);
      
      // Update comment count
      queryClient.setQueryData(["/api/feed"], (old: PostWithUser[] | undefined) => {
        if (!old) return old;
        return old.map(p => {
          if (p.id === post.id) {
            return {
              ...p,
              commentCount: p.commentCount + 1
            };
          }
          return p;
        });
      });
      
      queryClient.setQueryData(["/api/posts"], (old: PostWithUser[] | undefined) => {
        if (!old) return old;
        return old.map(p => {
          if (p.id === post.id) {
            return {
              ...p,
              commentCount: p.commentCount + 1
            };
          }
          return p;
        });
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add comment",
        variant: "destructive",
      });
    },
  });

  const fetchComments = async () => {
    if (!showCommentsSection) {
      setIsLoadingComments(true);
      try {
        const response = await fetch(`/api/posts/${post.id}/comments`, {
          credentials: 'include'
        });
        const data = await response.json();
        setComments(data);
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to load comments",
          variant: "destructive",
        });
      } finally {
        setIsLoadingComments(false);
      }
    }
    setShowCommentsSection(!showCommentsSection);
  };

  return (
    <Card className="mb-4">
      <CardHeader className="pb-2 pt-4 px-4">
        <div className="flex justify-between items-center">
          <Link href={`/profile/${post.user.id}`} className="flex items-center space-x-2 hover:opacity-80">
            <UserAvatar user={post.user} />
            <div>
              <div className="font-medium">{post.user.displayName}</div>
              <div className="text-xs text-muted-foreground">@{post.user.username}</div>
            </div>
          </Link>
          <div className="flex items-center space-x-2 text-muted-foreground text-sm">
            <span>{formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}</span>
            
            {user?.id === post.user.id && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem
                    className="text-destructive"
                    onClick={() => deletePostMutation.mutate()}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete post
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="px-4 py-3">
        <p className="whitespace-pre-wrap">{post.content}</p>
        {post.imageUrl && (
          <div className="mt-3 rounded-md overflow-hidden">
            <img src={post.imageUrl} alt="Post" className="w-full h-auto max-h-96 object-cover" />
          </div>
        )}
      </CardContent>
      <CardFooter className="px-4 py-2 flex flex-col">
        <div className="flex items-center space-x-4 w-full">
          <Button
            variant="ghost"
            size="sm"
            className={`flex items-center space-x-1 ${post.isLiked ? 'text-red-500' : ''}`}
            onClick={() => toggleLikeMutation.mutate()}
            disabled={toggleLikeMutation.isPending}
          >
            <Heart className={`h-5 w-5 ${post.isLiked ? 'fill-red-500' : ''}`} />
            <span>{post.likeCount}</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="flex items-center space-x-1"
            onClick={fetchComments}
          >
            <MessageCircle className="h-5 w-5" />
            <span>{post.commentCount}</span>
          </Button>
        </div>
        
        {showCommentsSection && (
          <div className="mt-4 space-y-4 w-full">
            <div className="flex space-x-2">
              <UserAvatar user={user || {}} size="sm" />
              <div className="flex-1">
                <Textarea
                  placeholder="Add a comment..."
                  value={commentContent}
                  onChange={(e) => setCommentContent(e.target.value)}
                  className="resize-none"
                />
                <div className="flex justify-end mt-2">
                  <Button 
                    size="sm" 
                    onClick={() => addCommentMutation.mutate()}
                    disabled={!commentContent.trim() || addCommentMutation.isPending}
                  >
                    Post
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              {isLoadingComments ? (
                <p className="text-sm text-center text-muted-foreground">Loading comments...</p>
              ) : comments.length > 0 ? (
                comments.map((comment) => (
                  <CommentItem key={comment.id} comment={comment} />
                ))
              ) : (
                <p className="text-sm text-center text-muted-foreground">No comments yet</p>
              )}
            </div>
          </div>
        )}
      </CardFooter>
    </Card>
  );
}
